import React, { useState } from 'react';
import { Button, Modal } from 'antd';
import Profile from './Profile';
const App = ({ isOpen, onClose}) => {
    
    const handleOk = () => {
        onClose();
    };
   
    return (
        <>
            
            <Modal title="Profile:" open={isOpen} onOk={handleOk} onCancel={onClose} footer={null} >
                <Profile />
            </Modal>
        </>
    );
};
export default App;