import React, { useState } from 'react';

// ANT-D :
import { Button, DatePicker, Input, Upload, theme, Select } from 'antd';


// ICONS :
import { PlusOutlined } from '@ant-design/icons';


// CSS :
import './style/Profile.scss'






const Profile = () => {
    const handleChange = (value) => {
        console.log(`selected ${value}`);
    };
    const { token } = theme.useToken();
    const style = {
        border: `1px solid ${token.colorPrimary}`,
        borderRadius: '50%',
    };
    const cellRender = (current, info) => {
        if (info.type !== 'date') {
            return info.originNode;
        }
        if (typeof current === 'number' || typeof current === 'string') {
            return <div className="ant-picker-cell-inner">{current}</div>;
        }
        return (
            <div className="ant-picker-cell-inner" style={current.date() === 1 ? style : {}}>
                {current.date()}
            </div>
        );
    };

    const [fileList, setFileList] = useState([]);
    const [previewImage, setPreviewImage] = useState(null);

    const onChangee = ({ fileList: newFileList }) => {
        setFileList(newFileList);
        if (newFileList.length > 0) {
            const file = newFileList[0].originFileObj;
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => setPreviewImage(reader.result);
        } else {
            setPreviewImage(null);
        }
    };
    const onPreview = async (file) => {
        let src = file.url;
        if (!src) {
            src = await new Promise((resolve) => {
                const reader = new FileReader();
                reader.readAsDataURL(file.originFileObj);
                reader.onload = () => resolve(reader.result);
            });
        }
        const imgWindow = window.open(src);
        imgWindow?.document.write(`<img src="${src}" alt="preview" />`);
    };




    return (
        <div className='profile-container' >
            {/* <div className='profile-heading'>
                <h2>Profile:</h2>
            </div> */}

            <div className='img-uploader'>
                <Upload
                    className="custom-upload"
                    action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
                    fileList={fileList}
                    multiple={false}
                    onChange={onChangee}
                    onPreview={onPreview}
                    showUploadList={false}
                    listType="picture-card"
                >
                    {previewImage ? (
                        <img
                            src={previewImage}
                            alt="preview"
                            style={{ borderRadius: '15px', width: '100%', height: '100%', objectFit: 'cover' }}
                        />
                    ) : (
                        <PlusOutlined style={{ fontSize: '15px'  }} />
                    )}
                </Upload>
            </div>

            <div className='form-box'>
                <Input placeholder="User Name" />
                <Input placeholder="Email" />
                <div> <Select
                    defaultValue="Gender"
                    style={{
                        width: 120,
                        marginRight:'12px'
                    }}
                    onChange={handleChange}
                    options={[
                        {
                            value: 'Male',
                            label: 'Male',
                        },
                        {
                            value: 'Female',
                            label: 'Female',
                        },


                    ]}
                /> <DatePicker cellRender={cellRender} />
                </div>




                <Button >Save</Button>
            </div>

        </div>

    );
}

export default Profile;
