import React from 'react'
import Navbar from '../Navbar'

function Home() {
    return (
        <>
        <Navbar/>
            <div style={{ height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

                <h1>Home</h1>
            </div>
        </>
    )
}

export default Home