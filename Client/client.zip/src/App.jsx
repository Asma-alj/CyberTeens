import { Route, Routes } from "react-router-dom";

// Components
import Login from '../src/Auth/Login'
import Signup from '../src/Auth/Signup'
import Home from "./components/pages/Home";
import Profile from "./components/Profile";

function App() {


  return (
    <>
      <Routes>
      <Route path="/" element={<Home/>} />
        <Route path="login" element={<Login />} />
        <Route path="signup" element={<Signup />} />
        <Route path="profile" element={<Profile />} />
      </Routes>

    </>
  )
}

export default App
