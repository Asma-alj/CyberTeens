// export const baseURL = 'https://tiktokfind.io/backend/api/v1';
// export const baseURL = 'http://195.35.8.53:5000/api/v1';

export const baseURL = 'http://localhost:5000';
export const baseURL2 = 'http://localhost:5000';
